﻿namespace interfacesAPI.dtos.DtosSalida
{
    public class GenerosDto
    {
        public int IdGenero { get; set; }
        public string Generos { get; set; }
    }
}
