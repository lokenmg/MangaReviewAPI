﻿namespace interfacesAPI.dtos.DtosEntrada
{
    public class NuevoUsuario
    {
        public string Email { get; set; } = null!;

        public string Contrasenia { get; set; } = null!;

        public string Img { get; set; } = null!;

    }
}
