﻿namespace interfacesAPI.dtos.DtosEntrada
{
    public class CrearReseniaDTO
    {   public string Resenia { get; set; }
        public int Likes { get; set; }
        public int Dislike { get; set; }
        public int Usuario { get; set; }
        public int Manga { get; set; }
    }
}
